A standalone, explicit GML representation of the ISO 19139 CV_DiscreteCoverage model, 
following the geometry-value pair (interleaved) pattern. 

SJDC 2006-12-12