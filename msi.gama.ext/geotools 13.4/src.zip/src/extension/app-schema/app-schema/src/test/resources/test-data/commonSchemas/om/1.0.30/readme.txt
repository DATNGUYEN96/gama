This is the current version of the O&M schema, developed primarily at CSIRO. 

Simon Cox - 2005-06-06
