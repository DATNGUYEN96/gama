NOTE: This version of the schemas refers to external schemas that are not yet public.
Therefore, you must configure you XML editor / validator with a Oasis Catalog and instruct
it to read local copies of the schemas that you will get from the SVN. Otherwise, the schemas 
(and instance documents) won't validate.

see https://www.seegrid.csiro.au/twiki/bin/view/CGIModel/ConfiguringXmlValidatorsForGeoSciML 
for complete instruction
