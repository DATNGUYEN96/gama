These files constitute governed re-usable schemas that geotools might well encounter in the wild.
 They are also likely to be shared across the test cases.

OASIS catalogs allow schema validation using these, and Geotools is being taught to use these.
 Currently OASIS catalogs seem to come in different flavours though.

Current implementation works with Oxygen

